export LD_LIBRARY_PATH=./lib
ulimit -n 65536
taskset f0 ./llm_demo-gpu-32k ./yourfile
