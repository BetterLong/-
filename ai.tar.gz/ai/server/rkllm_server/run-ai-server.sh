python3 gradio_server.py --target_platform rk3588 --rkllm_model_path /root/ai/yourfile
